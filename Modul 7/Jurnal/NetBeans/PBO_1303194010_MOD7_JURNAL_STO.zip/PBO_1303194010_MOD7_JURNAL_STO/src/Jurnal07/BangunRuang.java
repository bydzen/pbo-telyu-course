package Jurnal07;

public interface BangunRuang {
    public double hitungLuasPermukaan();
    public double hitungVolume();
}
