package Jurnal07;

public interface BangunDatar {
    public double hitungKeliling();
    public double hitungLuas();
}
