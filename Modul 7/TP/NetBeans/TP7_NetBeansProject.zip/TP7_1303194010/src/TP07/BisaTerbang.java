package TP07;

public interface BisaTerbang {
    public void terbang(int x, int y, int z);
}
