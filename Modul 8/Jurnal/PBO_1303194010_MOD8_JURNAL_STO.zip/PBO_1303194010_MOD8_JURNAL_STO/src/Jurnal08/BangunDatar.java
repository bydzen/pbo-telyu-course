package Jurnal08;

public class BangunDatar {
    private String nama;

    public BangunDatar(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }
    
    public double hitungKeliling() {
        return 0.0;
    }
    
    public double hitungLuas() {
        return 0.0;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    
}
